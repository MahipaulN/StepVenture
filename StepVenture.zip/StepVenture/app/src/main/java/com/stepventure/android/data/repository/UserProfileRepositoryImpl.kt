package com.stepventure.android.data.repository

import com.stepventure.android.data.local.dao.UserProfileDao
import com.stepventure.android.data.local.entity.UserProfileEntity
import com.stepventure.android.domain.model.Gender
import com.stepventure.android.domain.model.UserProfile
import com.stepventure.android.domain.repository.UserProfileRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class UserProfileRepositoryImpl @Inject constructor(
    private val userProfileDao: UserProfileDao
) : UserProfileRepository {

    override fun getUserProfile(): Flow<UserProfile?> {
        return userProfileDao.getUserProfile().map { entity ->
            entity?.toDomainModel()
        }
    }

    override suspend fun saveUserProfile(profile: UserProfile) {
        userProfileDao.insertOrUpdateProfile(profile.toEntity())
    }

    override suspend fun updateDailyStepGoal(newGoal: Int) {
        // In a real implementation, we would fetch current profile and update
        // For simplicity in foundation, we handle it in ViewModel for now
    }

    private fun UserProfileEntity.toDomainModel(): UserProfile {
        return UserProfile(
            id = id,
            name = name,
            age = age,
            gender = Gender.valueOf(gender),
            heightCm = heightCm,
            weightKg = weightKg,
            dailyStepGoal = dailyStepGoal,
            fitnessGoal = fitnessGoal,
            createdAt = createdAt,
            updatedAt = updatedAt
        )
    }

    private fun UserProfile.toEntity(): UserProfileEntity {
        return UserProfileEntity(
            id = id,
            name = name,
            age = age,
            gender = gender.name,
            heightCm = heightCm,
            weightKg = weightKg,
            dailyStepGoal = dailyStepGoal,
            fitnessGoal = fitnessGoal,
            createdAt = createdAt,
            updatedAt = System.currentTimeMillis()
        )
    }
}