package com.stepventure.android.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.stepventure.android.domain.engine.FitnessCalculationEngine
import com.stepventure.android.domain.model.DailyStep
import com.stepventure.android.domain.model.UserProfile
import com.stepventure.android.domain.repository.StepRepository
import com.stepventure.android.domain.repository.UserProfileRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch
import javax.inject.Inject

data class HomeUiState(
    val todaySteps: Int = 0,
    val caloriesBurned: Float = 0f,
    val distanceMeters: Float = 0f,
    val activeMinutes: Int = 0,
    val goalProgress: Float = 0f,
    val dailyGoal: Int = 8000,
    val isLoading: Boolean = true,
    val streak: Int = 0 // Placeholder for now
)

@HiltViewModel
class HomeViewModel @Inject constructor(
    private val stepRepository: StepRepository,
    private val userProfileRepository: UserProfileRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(HomeUiState())
    val uiState: StateFlow<HomeUiState> = _uiState.asStateFlow()

    init {
        observeData()
    }

    private fun observeData() {
        viewModelScope.launch {
            combine(
                stepRepository.getTodaySteps(),
                userProfileRepository.getUserProfile()
            ) { todayStep, profile ->
                mapToUiState(todayStep, profile)
            }.collect { newState ->
                _uiState.value = newState
            }
        }
    }

    private fun mapToUiState(dailyStep: DailyStep?, profile: UserProfile?): HomeUiState {
        val steps = dailyStep?.steps ?: 0
        val goal = profile?.dailyStepGoal ?: 8000

        val progress = FitnessCalculationEngine.calculateGoalProgress(steps, goal)

        return HomeUiState(
            todaySteps = steps,
            caloriesBurned = dailyStep?.caloriesBurned ?: 0f,
            distanceMeters = dailyStep?.distanceMeters ?: 0f,
            activeMinutes = dailyStep?.activeMinutes ?: 0,
            goalProgress = progress,
            dailyGoal = goal,
            isLoading = false,
            streak = 7 // TODO: Calculate real streak later
        )
    }

    fun refreshData() {
        // Can be used to force refresh if needed
        observeData()
    }
}