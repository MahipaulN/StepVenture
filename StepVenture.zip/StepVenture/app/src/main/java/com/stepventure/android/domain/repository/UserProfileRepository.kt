package com.stepventure.android.domain.repository

import com.stepventure.android.domain.model.UserProfile
import kotlinx.coroutines.flow.Flow

interface UserProfileRepository {
    fun getUserProfile(): Flow<UserProfile?>
    suspend fun saveUserProfile(profile: UserProfile)
    suspend fun updateDailyStepGoal(newGoal: Int)
}