package com.stepventure.android.domain.model

data class UserProfile(
    val id: Long = 0,
    val name: String,
    val age: Int,
    val gender: Gender,
    val heightCm: Float,
    val weightKg: Float,
    val dailyStepGoal: Int,
    val fitnessGoal: String? = null, // e.g., "Lose weight", "Build stamina", "Complete adventure"
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

enum class Gender {
    MALE, FEMALE, OTHER, PREFER_NOT_TO_SAY
}