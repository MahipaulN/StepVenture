package com.stepventure.android.ui.theme

import android.app.Activity
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

// Premium Fitness Color Palette
private val DarkColorScheme = darkColorScheme(
    primary = Color(0xFF00D4AA),           // Vibrant Teal
    onPrimary = Color(0xFF0F172A),
    primaryContainer = Color(0xFF00B894),
    onPrimaryContainer = Color(0xFF0F172A),
    
    secondary = Color(0xFF7C3AED),         // Purple accent
    onSecondary = Color.White,
    
    tertiary = Color(0xFF10B981),          // Success green
    
    background = Color(0xFF0F172A),        // Deep slate
    onBackground = Color(0xFFF1F5F9),
    
    surface = Color(0xFF1E293B),
    onSurface = Color(0xFFF1F5F9),
    surfaceVariant = Color(0xFF334155),
    onSurfaceVariant = Color(0xFF94A3B8),
    
    outline = Color(0xFF475569),
    error = Color(0xFFEF4444),
    onError = Color.White
)

private val LightColorScheme = lightColorScheme(
    primary = Color(0xFF00B894),
    onPrimary = Color.White,
    primaryContainer = Color(0xFF00D4AA),
    onPrimaryContainer = Color(0xFF0F172A),
    
    secondary = Color(0xFF7C3AED),
    onSecondary = Color.White,
    
    background = Color(0xFFF8FAFC),
    onBackground = Color(0xFF0F172A),
    
    surface = Color.White,
    onSurface = Color(0xFF0F172A),
    surfaceVariant = Color(0xFFE2E8F0),
    onSurfaceVariant = Color(0xFF475569),
    
    outline = Color(0xFF94A3B8),
    error = Color(0xFFDC2626),
    onError = Color.White
)

@Composable
fun StepVentureTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = true, // Enable dynamic color on Android 12+
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = !darkTheme
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = StepVentureTypography,
        content = content
    )
}