package com.stepventure.android.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.stepventure.android.data.local.entity.DailyStepEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface StepDao {

    @Query("SELECT * FROM daily_steps WHERE date = :date LIMIT 1")
    suspend fun getStepByDate(date: String): DailyStepEntity?

    @Query("SELECT * FROM daily_steps ORDER BY date DESC LIMIT 30")
    fun getLast30DaysSteps(): Flow<List<DailyStepEntity>>

    @Query("SELECT * FROM daily_steps WHERE date BETWEEN :startDate AND :endDate ORDER BY date ASC")
    fun getStepsBetweenDates(startDate: String, endDate: String): Flow<List<DailyStepEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateStep(step: DailyStepEntity)

    @Query("SELECT SUM(steps) FROM daily_steps WHERE date BETWEEN :startDate AND :endDate")
    suspend fun getTotalStepsInRange(startDate: String, endDate: String): Int?

    @Query("SELECT AVG(steps) FROM daily_steps WHERE date BETWEEN :startDate AND :endDate")
    suspend fun getAverageStepsInRange(startDate: String, endDate: String): Float?
}