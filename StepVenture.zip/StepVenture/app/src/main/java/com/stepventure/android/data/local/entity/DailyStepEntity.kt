package com.stepventure.android.data.local.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import java.time.LocalDate

@Entity(
    tableName = "daily_steps",
    indices = [Index(value = ["date"], unique = true)]
)
data class DailyStepEntity(
    @PrimaryKey val date: String, // Store as "yyyy-MM-dd" string for simplicity with Room
    val steps: Int,
    val caloriesBurned: Float,
    val distanceMeters: Float,
    val activeMinutes: Int,
    val lastUpdated: Long = System.currentTimeMillis()
)