package com.stepventure.android.domain.repository

import com.stepventure.android.domain.model.DailyStep
import kotlinx.coroutines.flow.Flow
import java.time.LocalDate

interface StepRepository {
    fun getTodaySteps(): Flow<DailyStep?>
    fun getLast30DaysSteps(): Flow<List<DailyStep>>
    suspend fun updateTodaySteps(steps: Int, calories: Float, distance: Float, activeMinutes: Int)
    suspend fun getStepCountForDate(date: LocalDate): Int
}