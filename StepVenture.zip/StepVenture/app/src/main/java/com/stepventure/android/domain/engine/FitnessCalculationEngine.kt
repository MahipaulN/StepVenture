package com.stepventure.android.domain.engine

import com.stepventure.android.domain.model.Gender
import com.stepventure.android.domain.model.UserProfile
import kotlin.math.roundToInt

/**
 * Production-grade fitness calculation engine.
 * Handles calories, distance, and activity metrics.
 */
object FitnessCalculationEngine {

    /**
     * Calculate calories burned from steps.
     * Uses MET (Metabolic Equivalent of Task) approach adjusted for user profile.
     */
    fun calculateCaloriesBurned(
        steps: Int,
        userProfile: UserProfile?
    ): Float {
        if (userProfile == null || steps <= 0) return 0f

        val weightKg = userProfile.weightKg
        val heightCm = userProfile.heightCm
        val age = userProfile.age
        val gender = userProfile.gender

        // Estimate stride length (more accurate than fixed 0.7m)
        val strideLengthMeters = estimateStrideLength(heightCm, gender)

        // Distance in km
        val distanceKm = (steps * strideLengthMeters) / 1000f

        // MET value for brisk walking ≈ 3.8
        // Adjust slightly based on estimated pace
        val met = 3.8f

        // Calories = MET × weight(kg) × time(hours)
        // Approximate time: assume average walking speed 5 km/h
        val hours = distanceKm / 5f

        val calories = met * weightKg * hours

        // Add small BMR component for the activity duration
        val bmrComponent = calculateBMR(weightKg, heightCm, age, gender) * (hours / 24f) * 0.3f

        return (calories + bmrComponent).coerceAtLeast(0f)
    }

    /**
     * Estimate stride length based on height and gender.
     * Average values from biomechanical studies.
     */
    private fun estimateStrideLength(heightCm: Float, gender: Gender): Float {
        val baseStride = when (gender) {
            Gender.MALE -> heightCm * 0.415f
            Gender.FEMALE -> heightCm * 0.413f
            else -> heightCm * 0.414f
        }
        return baseStride / 100f // convert to meters
    }

    /**
     * Basic BMR calculation (Mifflin-St Jeor)
     */
    private fun calculateBMR(weightKg: Float, heightCm: Float, age: Int, gender: Gender): Float {
        return when (gender) {
            Gender.MALE -> (10 * weightKg) + (6.25f * heightCm) - (5 * age) + 5
            Gender.FEMALE -> (10 * weightKg) + (6.25f * heightCm) - (5 * age) - 161
            else -> (10 * weightKg) + (6.25f * heightCm) - (5 * age) - 78 // average
        }
    }

    /**
     * Calculate distance walked in meters.
     */
    fun calculateDistanceMeters(steps: Int, userProfile: UserProfile?): Float {
        if (userProfile == null || steps <= 0) return steps * 0.7f // fallback

        val strideLength = estimateStrideLength(userProfile.heightCm, userProfile.gender)
        return steps * strideLength
    }

    /**
     * Estimate active minutes (rough heuristic).
     */
    fun estimateActiveMinutes(steps: Int): Int {
        if (steps <= 0) return 0
        // Assume average 100 steps per minute of walking
        return (steps / 100f).roundToInt().coerceAtLeast(1)
    }

    /**
     * Calculate goal completion percentage.
     */
    fun calculateGoalProgress(currentSteps: Int, dailyGoal: Int): Float {
        if (dailyGoal <= 0) return 0f
        return (currentSteps.toFloat() / dailyGoal).coerceIn(0f, 1f)
    }
}