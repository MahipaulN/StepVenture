package com.stepventure.android.ui.navigation

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.stepventure.android.ui.screens.home.HomeScreen
import com.stepventure.android.ui.screens.onboarding.OnboardingScreen
import com.stepventure.android.ui.screens.onboarding.PermissionSetupScreen

@Composable
fun StepVentureNavGraph(
    navController: NavHostController,
    startDestination: String = Screen.Splash.route
) {
    NavHost(
        navController = navController,
        startDestination = startDestination
    ) {
        composable(Screen.Splash.route) {
            // SplashScreen will navigate automatically
            SplashScreen(navController = navController)
        }

        composable(Screen.Onboarding.route) {
            OnboardingScreen(
                onFinishOnboarding = {
                    navController.navigate(Screen.PermissionSetup.route) {
                        popUpTo(Screen.Onboarding.route) { inclusive = true }
                    }
                }
            )
        }

        composable(Screen.PermissionSetup.route) {
            PermissionSetupScreen(
                onPermissionsGranted = {
                    navController.navigate(Screen.Home.route) {
                        popUpTo(Screen.PermissionSetup.route) { inclusive = true }
                    }
                }
            )
        }

        composable(Screen.Home.route) {
            HomeScreen(navController = navController)
        }

        // Other screens will be added in later iterations
        composable(Screen.Analytics.route) {
            // AnalyticsScreen()
        }
        composable(Screen.AICoach.route) {
            // AICoachScreen()
        }
        composable(Screen.Adventure.route) {
            // AdventureScreen()
        }
        composable(Screen.Profile.route) {
            // ProfileScreen()
        }
    }
}

@Composable
fun SplashScreen(navController: NavHostController) {
    // TODO: Replace with beautiful animated splash in next iteration
    // For now, auto-navigate to onboarding
    LaunchedEffect(Unit) {
        kotlinx.coroutines.delay(800)
        navController.navigate(com.stepventure.android.ui.navigation.Screen.Onboarding.route) {
            popUpTo(com.stepventure.android.ui.navigation.Screen.Splash.route) { inclusive = true }
        }
    }
    
    androidx.compose.foundation.layout.Box(
        modifier = androidx.compose.ui.Modifier.fillMaxSize(),
        contentAlignment = androidx.compose.ui.Alignment.Center
    ) {
        androidx.compose.material3.Text(
            text = "StepVenture",
            style = androidx.compose.material3.MaterialTheme.typography.displayLarge,
            color = androidx.compose.material3.MaterialTheme.colorScheme.primary
        )
    }
}