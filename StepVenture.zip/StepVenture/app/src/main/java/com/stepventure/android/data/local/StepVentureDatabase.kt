package com.stepventure.android.data.local

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.stepventure.android.data.local.dao.StepDao
import com.stepventure.android.data.local.dao.UserProfileDao
import com.stepventure.android.data.local.entity.DailyStepEntity
import com.stepventure.android.data.local.entity.UserProfileEntity

@Database(
    entities = [
        UserProfileEntity::class,
        DailyStepEntity::class
        // Future: JourneyProgressEntity, AchievementEntity, etc.
    ],
    version = 1,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class StepVentureDatabase : RoomDatabase() {

    abstract fun userProfileDao(): UserProfileDao
    abstract fun stepDao(): StepDao

    companion object {
        const val DATABASE_NAME = "stepventure_database"
    }
}