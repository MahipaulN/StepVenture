package com.stepventure.android.data.repository

import com.stepventure.android.data.local.dao.StepDao
import com.stepventure.android.data.local.entity.DailyStepEntity
import com.stepventure.android.domain.model.DailyStep
import com.stepventure.android.domain.repository.StepRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class StepRepositoryImpl @Inject constructor(
    private val stepDao: StepDao
) : StepRepository {

    private val dateFormatter = DateTimeFormatter.ISO_LOCAL_DATE

    override fun getTodaySteps(): Flow<DailyStep?> {
        val today = LocalDate.now().format(dateFormatter)
        return stepDao.getStepByDate(today).map { entity ->
            entity?.toDomainModel()
        }
    }

    override fun getLast30DaysSteps(): Flow<List<DailyStep>> {
        return stepDao.getLast30DaysSteps().map { list ->
            list.map { it.toDomainModel() }
        }
    }

    override suspend fun updateTodaySteps(steps: Int, calories: Float, distance: Float, activeMinutes: Int) {
        val today = LocalDate.now().format(dateFormatter)

        val entity = DailyStepEntity(
            date = today,
            steps = steps,
            caloriesBurned = calories,
            distanceMeters = distance,
            activeMinutes = activeMinutes
        )
        stepDao.insertOrUpdateStep(entity)
    }

    override suspend fun getStepCountForDate(date: LocalDate): Int {
        val dateStr = date.format(dateFormatter)
        return stepDao.getStepByDate(dateStr)?.steps ?: 0
    }

    private fun DailyStepEntity.toDomainModel(): DailyStep {
        return DailyStep(
            date = LocalDate.parse(this.date, dateFormatter),
            steps = this.steps,
            caloriesBurned = this.caloriesBurned,
            distanceMeters = this.distanceMeters,
            activeMinutes = this.activeMinutes,
            goalAchieved = false // Will be calculated in ViewModel using user goal
        )
    }
}