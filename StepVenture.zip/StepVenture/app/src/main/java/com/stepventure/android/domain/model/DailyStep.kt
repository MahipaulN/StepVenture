package com.stepventure.android.domain.model

import java.time.LocalDate

data class DailyStep(
    val date: LocalDate,
    val steps: Int,
    val caloriesBurned: Float,
    val distanceMeters: Float,
    val activeMinutes: Int,
    val goalAchieved: Boolean = steps >= 0 // Will be calculated with user goal
)