package com.stepventure.android.di

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.preferencesDataStore
import androidx.room.Room
import com.stepventure.android.data.local.StepVentureDatabase
import com.stepventure.android.data.local.dao.StepDao
import com.stepventure.android.data.local.dao.UserProfileDao
import com.stepventure.android.data.repository.UserProfileRepositoryImpl
import com.stepventure.android.domain.repository.UserProfileRepository
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "stepventure_preferences")

@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {

    @Provides
    @Singleton
    fun provideDatabase(@ApplicationContext context: Context): StepVentureDatabase {
        return Room.databaseBuilder(
            context,
            StepVentureDatabase::class.java,
            StepVentureDatabase.DATABASE_NAME
        )
        .fallbackToDestructiveMigration()
        .build()
    }

    @Provides
    fun provideUserProfileDao(database: StepVentureDatabase): UserProfileDao {
        return database.userProfileDao()
    }

    @Provides
    fun provideStepDao(database: StepVentureDatabase): StepDao {
        return database.stepDao()
    }

    @Provides
    @Singleton
    fun provideUserProfileRepository(
        userProfileDao: UserProfileDao
    ): UserProfileRepository {
        return UserProfileRepositoryImpl(userProfileDao)
    }

    @Provides
    @Singleton
    fun provideDataStore(@ApplicationContext context: Context): DataStore<Preferences> {
        return context.dataStore
    }

    @Provides
    @Singleton
    fun provideStepRepository(
        stepDao: StepDao
    ): StepRepository {
        return StepRepositoryImpl(stepDao)
    }
}