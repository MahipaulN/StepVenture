package com.stepventure.android

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class StepVentureApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        // Future: Initialize any analytics, crash reporting, or WorkManager configuration here
    }
}