package com.stepventure.android.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.stepventure.android.MainActivity
import com.stepventure.android.R
import com.stepventure.android.domain.engine.FitnessCalculationEngine
import com.stepventure.android.domain.model.UserProfile
import com.stepventure.android.domain.repository.StepRepository
import com.stepventure.android.domain.repository.UserProfileRepository
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import javax.inject.Inject

/**
 * Foreground Service that listens to step sensor and updates daily steps.
 * Survives when app is in background or killed (to some extent).
 */
@AndroidEntryPoint
class StepTrackingService : Service(), SensorEventListener {

    @Inject
    lateinit var stepRepository: StepRepository

    @Inject
    lateinit var userProfileRepository: UserProfileRepository

    private lateinit var sensorManager: SensorManager
    private var stepSensor: Sensor? = null

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    private var lastSensorSteps: Int = 0
    private var todayBaseline: Int = 0
    private var currentDate: String = getCurrentDateString()

    companion object {
        const val CHANNEL_ID = "step_tracking_channel"
        const val NOTIFICATION_ID = 1001
    }

    override fun onCreate() {
        super.onCreate()
        sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        stepSensor = sensorManager.getDefaultSensor(Sensor.TYPE_STEP_COUNTER)

        createNotificationChannel()
        startForeground(NOTIFICATION_ID, createNotification(0))

        // Start listening to sensor
        stepSensor?.let {
            sensorManager.registerListener(
                this,
                it,
                SensorManager.SENSOR_DELAY_UI
            )
        }

        // Load today's baseline from storage (simplified - in real app use DataStore)
        serviceScope.launch {
            loadTodayBaseline()
        }
    }

    private suspend fun loadTodayBaseline() {
        // In production, we would store baseline in DataStore keyed by date
        // For now, we assume first reading of the day becomes baseline
        val today = getCurrentDateString()
        val existing = stepRepository.getStepCountForDate(LocalDate.parse(today))
        if (existing > 0) {
            // If we already have steps today, we need the baseline from previous sensor value
            // This is simplified. Real implementation stores last sensor value + date.
        }
    }

    override fun onSensorChanged(event: SensorEvent?) {
        if (event?.sensor?.type == Sensor.TYPE_STEP_COUNTER) {
            val totalStepsSinceReboot = event.values[0].toInt()

            serviceScope.launch {
                handleNewStepCount(totalStepsSinceReboot)
            }
        }
    }

    private suspend fun handleNewStepCount(totalStepsSinceReboot: Int) {
        val today = getCurrentDateString()

        // Check if day changed (midnight reset)
        if (today != currentDate) {
            currentDate = today
            todayBaseline = totalStepsSinceReboot
            // Save new baseline for new day (in real app → DataStore)
        }

        if (todayBaseline == 0) {
            todayBaseline = totalStepsSinceReboot
        }

        val stepsToday = (totalStepsSinceReboot - todayBaseline).coerceAtLeast(0)

        // Get user profile for calculations
        val userProfile = userProfileRepository.getUserProfile().first()

        val calories = FitnessCalculationEngine.calculateCaloriesBurned(stepsToday, userProfile)
        val distance = FitnessCalculationEngine.calculateDistanceMeters(stepsToday, userProfile)
        val activeMinutes = FitnessCalculationEngine.estimateActiveMinutes(stepsToday)

        // Update repository (Room)
        stepRepository.updateTodaySteps(
            steps = stepsToday,
            calories = calories,
            distance = distance,
            activeMinutes = activeMinutes
        )

        // Update notification
        updateNotification(stepsToday)
    }

    private fun updateNotification(steps: Int) {
        val notification = createNotification(steps)
        val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        notificationManager.notify(NOTIFICATION_ID, notification)
    }

    private fun createNotification(steps: Int): Notification {
        val intent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        }

        val pendingIntent = PendingIntent.getActivity(
            this, 0, intent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("StepVenture is tracking")
            .setContentText("$steps steps today")
            .setSmallIcon(android.R.drawable.ic_menu_directions) // Replace with real icon later
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .setSilent(true)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Step Tracking",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Keeps step tracking active"
                setShowBadge(false)
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {
        // Not needed for step counter
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        sensorManager.unregisterListener(this)
        serviceScope.cancel()
    }

    private fun getCurrentDateString(): String {
        return LocalDate.now().format(DateTimeFormatter.ISO_LOCAL_DATE)
    }
}