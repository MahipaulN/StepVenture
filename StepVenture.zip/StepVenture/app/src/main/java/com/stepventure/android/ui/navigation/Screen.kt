package com.stepventure.android.ui.navigation

sealed class Screen(val route: String) {
    data object Splash : Screen("splash")
    data object Onboarding : Screen("onboarding")
    data object PermissionSetup : Screen("permission_setup")
    data object Home : Screen("home")
    data object Analytics : Screen("analytics")
    data object AICoach : Screen("ai_coach")
    data object Adventure : Screen("adventure")
    data object Profile : Screen("profile")
}