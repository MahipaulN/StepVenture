package com.stepventure.android.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "user_profile")
data class UserProfileEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val age: Int,
    val gender: String, // Store as string for simplicity
    val heightCm: Float,
    val weightKg: Float,
    val dailyStepGoal: Int,
    val fitnessGoal: String?,
    val createdAt: Long,
    val updatedAt: Long
)